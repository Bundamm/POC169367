package moto;

public class TestVehicle {
    public static void main(String[] args) {
        Vehicle c1 = Vehicle.createCar("Mdwa","Cawfaf", 2003);
        Vehicle v1 = new Vehicle();
        v1 =  v1.createVehicle("fewawa", "12dff", 2002);
    }
}
