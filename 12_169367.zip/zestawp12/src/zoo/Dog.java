package zoo;

public class Dog extends Animal{
    @Override
    public String makeSound() {
        return "Bark";
    }
}
