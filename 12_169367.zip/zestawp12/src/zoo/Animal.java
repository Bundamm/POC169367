package zoo;

public abstract class Animal {
    public abstract String makeSound();
}
