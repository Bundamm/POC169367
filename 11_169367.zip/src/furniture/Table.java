package furniture;

public class Table {
    private double price;

    private Table(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }
}
